#!/usr/bin/env python3
"""Patch the pinned open-source Scropy Android client for Google TV touch control.
Upstream is fetched by GitHub Actions (MIT licensed). Fail fast if code drifts.
"""
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
src = root / 'app/src/main/java/tech/devline/scropy_ui'
activity = src / 'StreamActivity.kt'
sender = src / 'scrcpy/ControlSender.kt'
gradle = root / 'app/build.gradle.kts'


def replace(path: Path, original: str, updated: str, count: int = 1):
    content = path.read_text('utf-8')
    actual = content.count(original)
    if actual != count:
        raise SystemExit(f'PATCH ERROR: {path}: expected {count} occurrences; found {actual}: {original[:85]!r}')
    path.write_text(content.replace(original, updated), encoding='utf-8')

# 1. Video is for navigating UI, not watching video. Audio disabled.
replace(activity, 'import android.os.Bundle', 'import android.os.Bundle\nimport android.content.pm.ActivityInfo\nimport android.view.KeyEvent\nimport kotlin.math.abs')
replace(activity, '        super.onCreate(savedInstanceState)\n',
        '        super.onCreate(savedInstanceState)\n        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE\n')
replace(activity, 'private const val DEFAULT_VIDEO_BIT_RATE = 4_000_000',
        'private const val DEFAULT_VIDEO_BIT_RATE = 1_500_000')
replace(activity, '    private var screenOn    = mutableStateOf(true)',
'''    private var screenOn    = mutableStateOf(true)
    // True = swipe to TV D-pad navigation, false = native touchscreen gestures.
    private var tvScrollMode = mutableStateOf(true)
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStepX = 0f
    private var gestureStepY = 0f
    private var gestureIsSwipe = false

    private fun handleTvTouch(ev: MotionEvent, w: Int, h: Int) {
        val ctrl = controlSender ?: return
        if (!tvScrollMode.value || ev.pointerCount > 1) {
            ctrl.sendTouchEvent(ev, w, h)
            return
        }
        // Small swipe step for responsive menus; avoiding MOVE floods is critical.
        val step = 30f * resources.displayMetrics.density
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureStartX = ev.x
                gestureStartY = ev.y
                gestureStepX = ev.x
                gestureStepY = ev.y
                gestureIsSwipe = false
            }
            MotionEvent.ACTION_MOVE -> {
                val vertical = abs(ev.y - gestureStartY) >= abs(ev.x - gestureStartX)
                if (!gestureIsSwipe && (abs(ev.x - gestureStartX) > step || abs(ev.y - gestureStartY) > step)) {
                    gestureIsSwipe = true
                }
                if (!gestureIsSwipe) return
                val delta = if (vertical) ev.y - gestureStepY else ev.x - gestureStepX
                val count = (abs(delta) / step).toInt().coerceAtMost(5)
                if (count > 0) {
                    val key = when {
                        vertical && delta < 0 -> KeyEvent.KEYCODE_DPAD_DOWN
                        vertical -> KeyEvent.KEYCODE_DPAD_UP
                        delta < 0 -> KeyEvent.KEYCODE_DPAD_RIGHT
                        else -> KeyEvent.KEYCODE_DPAD_LEFT
                    }
                    repeat(count) { ctrl.sendKeyTap(key) }
                    if (vertical) gestureStepY += if (delta > 0) count * step else -count * step
                    else gestureStepX += if (delta > 0) count * step else -count * step
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!gestureIsSwipe) ctrl.sendTap(ev.x, ev.y, w, h)
            }
            MotionEvent.ACTION_CANCEL -> gestureIsSwipe = false
        }
    }

    private fun handleTvScroll(ev: MotionEvent, w: Int, h: Int) {
        val ctrl = controlSender ?: return
        if (!tvScrollMode.value) { ctrl.sendScrollEvent(ev, w, h); return }
        val delta = ev.getAxisValue(MotionEvent.AXIS_VSCROLL)
        if (delta != 0f) repeat(abs(delta).toInt().coerceAtLeast(1).coerceAtMost(5)) {
            ctrl.sendKeyTap(if (delta > 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN)
        }
    }''')
replace(activity, '                    screenOn    = screenOn.value,',
'''                    screenOn    = screenOn.value,
                    tvScrollMode = tvScrollMode.value,
                    onToggleMode = { tvScrollMode.value = !tvScrollMode.value },
                    onNav = { keyCode -> controlSender?.sendKeyTap(keyCode) },''')
replace(activity, '                    onTouchEvent        = { ev, w, h -> controlSender?.sendTouchEvent(ev, w, h) },',
        '                    onTouchEvent        = { ev, w, h -> handleTvTouch(ev, w, h) },')
replace(activity, '                    onScrollEvent       = { ev, w, h -> controlSender?.sendScrollEvent(ev, w, h) },',
        '                    onScrollEvent       = { ev, w, h -> handleTvScroll(ev, w, h) },')
replace(activity, '                    enableAudio = true,', '                    enableAudio = false,\n                    maxSize     = 1280,', 2)
replace(activity, '        decodeJob?.cancel()\n', '        controlSender?.shutdown()\n        decodeJob?.cancel()\n')
# Update StreamScreen function signature AND FloatingControls signature with exact snippets
replace(activity, '    screenOn: Boolean,\n    onToggleScreen: () -> Unit,\n',
'''    screenOn: Boolean,
    tvScrollMode: Boolean,
    onToggleMode: () -> Unit,
    onNav: (Int) -> Unit,
    onToggleScreen: () -> Unit,
''', 2)
replace(activity, '                screenOn       = screenOn,\n                onToggleScreen = onToggleScreen,',
'''                screenOn       = screenOn,
                tvScrollMode  = tvScrollMode,
                onToggleMode  = onToggleMode,
                onNav         = onNav,
                onToggleScreen = onToggleScreen,''')
replace(activity, '                MenuItem("Disconnect", onDisconnect)\n',
'''                MenuItem(if (tvScrollMode) "MODE: TV swipe / D-pad" else "MODE: direct touch", onToggleMode)
                Row {
                    MenuItem("↑", { onNav(KeyEvent.KEYCODE_DPAD_UP) })
                    MenuItem("↓", { onNav(KeyEvent.KEYCODE_DPAD_DOWN) })
                    MenuItem("←", { onNav(KeyEvent.KEYCODE_DPAD_LEFT) })
                    MenuItem("→", { onNav(KeyEvent.KEYCODE_DPAD_RIGHT) })
                }
                Row {
                    MenuItem("OK", { onNav(KeyEvent.KEYCODE_DPAD_CENTER) })
                    MenuItem("BACK", { onNav(KeyEvent.KEYCODE_BACK) })
                    MenuItem("HOME", { onNav(KeyEvent.KEYCODE_HOME) })
                }
                MenuItem("Disconnect", onDisconnect)
''')

# 2. Control queue. Send on background thread, throttle MOVE, protect UI thread.
replace(sender, 'import android.view.MotionEvent',
        'import android.view.MotionEvent\nimport java.util.concurrent.LinkedBlockingDeque')
replace(sender, '    @Volatile var deviceHeight: Int = 0',
'''    @Volatile var deviceHeight: Int = 0

    private val outgoing = LinkedBlockingDeque<ByteArray>(48)
    @Volatile private var running = true
    @Volatile private var lastMoveNs = 0L
    private val writer = Thread({
        while (running) {
            try {
                stream.write(outgoing.takeFirst())
            } catch (_: InterruptedException) {
                break
            } catch (e: IOException) {
                Log.w(TAG, "Remote control writer stopped: ${e.message}")
                break
            }
        }
    }, "tv-touch-writer").apply { isDaemon = true; start() }

    fun shutdown() {
        running = false
        writer.interrupt()
        outgoing.clear()
    }

    // Short press: TV interfaces understand this even without touchscreen support.
    fun sendKeyTap(keyCode: Int) {
        sendKeyEvent(0, keyCode)
        sendKeyEvent(1, keyCode)
    }

    fun sendTap(sx: Float, sy: Float, sw: Int, sh: Int) {
        if (deviceWidth <= 0 || deviceHeight <= 0 || sw <= 0 || sh <= 0) return
        val x = (sx / sw * deviceWidth).toInt().coerceIn(0, deviceWidth - 1)
        val y = (sy / sh * deviceHeight).toInt().coerceIn(0, deviceHeight - 1)
        // Use a real finger pointer ID (not the special 'mouse' pointer -1).
        send(ScrcpyProtocol.buildTouchEvent(0, 0L, x, y, deviceWidth, deviceHeight, 1f))
        send(ScrcpyProtocol.buildTouchEvent(1, 0L, x, y, deviceWidth, deviceHeight, 0f))
    }''')
replace(sender, '''        if (deviceWidth == 0 || deviceHeight == 0) return

        val action''',
'''        if (deviceWidth <= 0 || deviceHeight <= 0 || surfaceWidth <= 0 || surfaceHeight <= 0) return
        if (event.actionMasked == MotionEvent.ACTION_MOVE) {
            val now = System.nanoTime()
            if (now - lastMoveNs < 16_000_000L) return
            lastMoveNs = now
        }

        val action''')
replace(sender, '        val x = (event.getX(pointerIdx) / surfaceWidth  * deviceWidth).toInt()',
        '        val x = (event.getX(pointerIdx) / surfaceWidth  * deviceWidth).toInt().coerceIn(0, deviceWidth - 1)')
replace(sender, '        val y = (event.getY(pointerIdx) / surfaceHeight * deviceHeight).toInt()',
        '        val y = (event.getY(pointerIdx) / surfaceHeight * deviceHeight).toInt().coerceIn(0, deviceHeight - 1)')
replace(sender, '''    private fun send(data: ByteArray) {
        try {
            stream.write(data)
        } catch (e: IOException) {
            Log.w(TAG, "Control send failed: ${e.message}")
        }
    }''',
'''    private fun send(data: ByteArray) {
        if (!running) return
        val isMove = data.size > 1 &&
            data[0].toInt() == ScrcpyProtocol.TYPE_INJECT_TOUCH_EVENT &&
            data[1].toInt() == MotionEvent.ACTION_MOVE
        if (outgoing.offerLast(data)) return
        if (isMove) return // Never allow drag frames to back up click/key input.
        // On saturation, replace a queued move, preserving down/up key ordering.
        val move = outgoing.firstOrNull { msg -> msg.size > 1 &&
            msg[0].toInt() == ScrcpyProtocol.TYPE_INJECT_TOUCH_EVENT &&
            msg[1].toInt() == MotionEvent.ACTION_MOVE }
        if (move != null) outgoing.remove(move)
        if (!outgoing.offerLast(data)) {
            Log.w(TAG, "Control queue full: dropped a command")
        }
    }''')
replace(sender, '''    private fun normalizePointerId(androidId: Int): Long =
        if (androidId == 0) ScrcpyProtocol.POINTER_MOUSE else androidId.toLong()''',
'''    private fun normalizePointerId(androidId: Int): Long = androidId.toLong()''')

# 3. Branding and version: keep package compatible with upstream while user tests v1.
replace(gradle, 'versionName = "1.0"', 'versionName = "1.0-TVTouch"')
print('PATCH OK: TV gestures, queued control, 720p streaming, no audio, floating D-pad')


# 4. v1.2 Fold6: native 16:9 video without stretching, symmetric black-bar controls.
# Preserve all existing ADB connections, pairing, direct touch, TV swipe and navigation.
replace(activity, 'requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE',
        'requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE') if False else None
# Keep landscape to make both thumb-friendly sidebars always available on Fold6.
replace(activity, 'maxSize     = 1280,', 'maxSize     = 1920,', 2)
replace(activity, 'private const val DEFAULT_VIDEO_BIT_RATE = 1_500_000',
        'private const val DEFAULT_VIDEO_BIT_RATE = 2_500_000')
replace(activity, 'import androidx.compose.ui.unit.IntOffset',
        'import androidx.compose.ui.unit.IntOffset\nimport androidx.compose.ui.unit.sp')
replace(gradle, 'versionName = "1.0-TVTouch"', 'versionName = "1.2-TVTouch-Fold6"')

# Replace ONLY the old Composable screen/overlay. Transport and control lifecycle unchanged.
screen_head = '@Composable\nprivate fun StreamScreen('
content = activity.read_text('utf-8')
if content.count(screen_head) != 1:
    raise SystemExit('PATCH ERROR: StreamScreen marker changed upstream')
new_ui = r'''@Composable
private fun StreamScreen(
    statusText: String,
    errorText: String?,
    isConnected: Boolean,
    screenOn: Boolean,
    tvScrollMode: Boolean,
    onToggleMode: () -> Unit,
    onNav: (Int) -> Unit,
    onToggleScreen: () -> Unit,
    onSurfaceReady: (Surface) -> Unit,
    onSurfaceDestroyed: () -> Unit,
    onTouchEvent: (MotionEvent, Int, Int) -> Unit,
    onScrollEvent: (MotionEvent, Int, Int) -> Unit,
    onDisconnect: () -> Unit,
    onRetry: () -> Unit,
) {
    // Landscape is intentional: reserve strips for thumb controls on BOTH sides.
    // The 16:9 picture is fitted INSIDE the remaining centre, never stretched.
    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val railWidth = (maxWidth * 0.125f).coerceIn(64.dp, 112.dp)
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                TvControlRail(
                    modifier = Modifier.width(railWidth).fillMaxHeight(),
                    isLeft = true,
                    isConnected = isConnected,
                    tvScrollMode = tvScrollMode,
                    onToggleMode = onToggleMode,
                    onNav = onNav,
                    onDisconnect = onDisconnect,
                )
                TvVideoFrame(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    statusText = statusText,
                    errorText = errorText,
                    isConnected = isConnected,
                    onSurfaceReady = onSurfaceReady,
                    onSurfaceDestroyed = onSurfaceDestroyed,
                    onTouchEvent = onTouchEvent,
                    onScrollEvent = onScrollEvent,
                    onRetry = onRetry,
                    onDisconnect = onDisconnect,
                )
                TvControlRail(
                    modifier = Modifier.width(railWidth).fillMaxHeight(),
                    isLeft = false,
                    isConnected = isConnected,
                    tvScrollMode = tvScrollMode,
                    onToggleMode = onToggleMode,
                    onNav = onNav,
                    onDisconnect = onDisconnect,
                )
            }
        }
    }
}

/** Hardware-decoded SurfaceView contained in a strict 16:9 viewport.
 *  The view's measured size is the true video size displayed on the phone;
 *  touch coordinates go directly to this view, EXCLUDING black bars. */
@Composable
private fun TvVideoFrame(
    modifier: Modifier,
    statusText: String,
    errorText: String?,
    isConnected: Boolean,
    onSurfaceReady: (Surface) -> Unit,
    onSurfaceDestroyed: () -> Unit,
    onTouchEvent: (MotionEvent, Int, Int) -> Unit,
    onScrollEvent: (MotionEvent, Int, Int) -> Unit,
    onRetry: () -> Unit,
    onDisconnect: () -> Unit,
) {
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val parentRatio = if (maxHeight.value > 0f) maxWidth.value / maxHeight.value else 1f
        val viewportModifier = if (parentRatio <= 16f / 9f) {
            Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        } else {
            Modifier.fillMaxHeight().aspectRatio(16f / 9f)
        }
        Box(modifier = viewportModifier, contentAlignment = Alignment.Center) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    SurfaceView(ctx).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
                        holder.addCallback(object : SurfaceHolder.Callback {
                            override fun surfaceCreated(h: SurfaceHolder) = onSurfaceReady(h.surface)
                            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) = Unit
                            override fun surfaceDestroyed(h: SurfaceHolder) = onSurfaceDestroyed()
                        })
                        setOnTouchListener { v, ev ->
                            when (ev.actionMasked) {
                                MotionEvent.ACTION_SCROLL -> onScrollEvent(ev, v.width, v.height)
                                else -> onTouchEvent(ev, v.width, v.height)
                            }
                            true
                        }
                    }
                }
            )
            if (!isConnected) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xF510151C)) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        if (errorText != null) {
                            Text("连接失败", color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            Text(errorText, color = Color.White,
                                style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = onRetry) { Text("重试") }
                                OutlinedButton(onClick = onDisconnect) { Text("返回") }
                            }
                        } else {
                            CircularProgressIndicator()
                            Spacer(Modifier.height(10.dp))
                            Text(statusText, color = Color.White,
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

/** Two always-visible side rails, positioned for Fold6 left/right thumbs. */
@Composable
private fun TvControlRail(
    modifier: Modifier,
    isLeft: Boolean,
    isConnected: Boolean,
    tvScrollMode: Boolean,
    onToggleMode: () -> Unit,
    onNav: (Int) -> Unit,
    onDisconnect: () -> Unit,
) {
    Column(
        modifier = modifier.padding(horizontal = 5.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (isLeft) {
            TvRailButton("▲ 上", enabled = isConnected) { onNav(KeyEvent.KEYCODE_DPAD_UP) }
            TvRailButton("▼ 下", enabled = isConnected) { onNav(KeyEvent.KEYCODE_DPAD_DOWN) }
            TvRailButton("⇡ 上翻", enabled = isConnected) {
                repeat(5) { onNav(KeyEvent.KEYCODE_DPAD_UP) }
            }
            TvRailButton("⇣ 下翻", enabled = isConnected) {
                repeat(5) { onNav(KeyEvent.KEYCODE_DPAD_DOWN) }
            }
            TvRailButton("↩ 返回", enabled = isConnected) { onNav(KeyEvent.KEYCODE_BACK) }
        } else {
            TvRailButton("◀ 左", enabled = isConnected) { onNav(KeyEvent.KEYCODE_DPAD_LEFT) }
            TvRailButton("右 ▶", enabled = isConnected) { onNav(KeyEvent.KEYCODE_DPAD_RIGHT) }
            TvRailButton("● 确定", enabled = isConnected, primary = true) {
                onNav(KeyEvent.KEYCODE_DPAD_CENTER)
            }
            TvRailButton("⌂ 主页", enabled = isConnected) { onNav(KeyEvent.KEYCODE_HOME) }
            TvRailButton(if (tvScrollMode) "滑动翻页" else "直接触摸", enabled = isConnected,
                primary = !tvScrollMode) { onToggleMode() }
            TvRailButton("× 退出") { onDisconnect() }
        }
    }
}

@Composable
private fun TvRailButton(
    title: String,
    enabled: Boolean = true,
    primary: Boolean = false,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(43.dp),
        shape = RoundedCornerShape(12.dp),
        color = if (primary) Color(0xFF176E78) else Color(0xFF252B34),
        contentColor = Color.White,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(title, color = Color.White, fontSize = 12.sp, maxLines = 1)
        }
    }
}
'''
activity.write_text(content.split(screen_head, 1)[0] + new_ui, encoding='utf-8')

strings = root / 'app/src/main/res/values/strings.xml'
replace(strings, '<string name="app_name">Scropy</string>',
        '<string name="app_name">TV TouchMirror</string>')
print('v1.2 OK: 1920 max capture, fixed 16:9 viewport, sidebars, no touch offset')
