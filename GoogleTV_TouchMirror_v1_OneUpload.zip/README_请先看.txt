GoogleTV TouchMirror v1 — 专用手机触控电视镜像 APK（研究试验版）
=========================================================
目的：在安卓手机显示 Google TV 画面，在手机直接点击或用滑动操作电视。

技术基础：
- feggaa/scrcpy-android（MIT 开源；安卓控制安卓，无需电脑）
- Genymobile/scrcpy v4.1 Server（Apache-2.0）
- GoogleTV 优化由 patch/patch_tv.py 修改源代码

目前的功能：
1) 手机端显示电视画面，强制横屏
2) 提供两种模式：TV swipe / D-pad（默认）和 direct touch
3) TV 模式：手指向上滑 = 连续向下导航；点画面 = 尝试真实触摸
4) 浮动菜单：切换模式、方向键、OK、BACK、HOME、断开
5) 控制消息后台队列发送，不让网络写入卡住 UI 主线程
6) 30fps、长边最大1280像素、1.5Mbps、音频关闭
7) 支持上游原有的无线配对 / Wi-Fi ADB / USB OTG（需要设备支持）

这是生成用的“补丁工程”，不是已经编译成功的 APK。
此运行环境无法访问外部 Android SDK/GitHub 网络进行真实 APK 构建。
请用 GitHub Actions 编译后在手机和 Google TV 进行兼容性、点击及滑动实测。

【第一次创建仓库】
1. GitHub 新建一个空的仓库，如 GoogleTV-TouchMirror。
2. 在仓库根目录上传不解压的 GoogleTV_TouchMirror_v1_OneUpload.zip。
3. GitHub 仓库进入 Add file → Create new file，文件名填：
   .github/workflows/build-apk.yml
   将单独提供的 build-apk_GoogleTV_TouchMirror_v1.yml 内容复制粘贴并提交。
4. 点击 Actions → Build GoogleTV TouchMirror APK → Run workflow。
5. 构建成功后，在该次 Actions 页面最下面 Artifacts 下载 APK。

【后续更新】
后续只需上传同名 ZIP 覆盖仓库中的文件，自动触发已有 workflow；无需每次重新配置。

【手机连接电视】
- 手机安装 APK；Google TV 打开开发者选项、无线调试。
- 手机、电视在同一 Wi-Fi；使用客户端“ADB over Wi-Fi”，按电视显示的配对端口配对。
- 配对端口与连接端口可能不同，连接时使用电视当前显示的调试连接端口。
- 点击 Stream，出现电视实时画面后，用小圆钮切换操作模式。

【电视操作的客观限制】
Google TV 部分原生界面不支持触屏点击，TV 滑动/方向键模式可以绕过一部分限制，
但不能把原生 TV 应用真正变成触屏应用。触摸到坐标不必然表示 TV 会响应。
受保护视频（DRM）可能黑屏；不支持外部 HDMI 输入采集。

【原始项目】
https://github.com/feggaa/scrcpy-android
https://github.com/Genymobile/scrcpy

版本：v1.0 测试工程，2026-10-21
