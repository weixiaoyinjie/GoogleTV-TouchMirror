#!/usr/bin/env python3
"""Patch the pinned open-source Scropy Android client for Google TV touch control.
Upstream is fetched by GitHub Actions (MIT licensed). Fail fast if code drifts.
"""
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
src = root / 'app/src/main/java/tech/devline/scropy_ui'
activity = src / 'StreamActivity.kt'
sender = src / 'scrcpy/ControlSender.kt'
gradle = root / 'app/build.gradle.kts'


def replace(path: Path, original: str, updated: str, count: int = 1):
    content = path.read_text('utf-8')
    actual = content.count(original)
    if actual != count:
        raise SystemExit(f'PATCH ERROR: {path}: expected {count} occurrences; found {actual}: {original[:85]!r}')
    path.write_text(content.replace(original, updated), encoding='utf-8')

# 1. Video is for navigating UI, not watching video. Audio disabled.
replace(activity, 'import android.os.Bundle', 'import android.os.Bundle\nimport android.content.pm.ActivityInfo\nimport android.view.KeyEvent\nimport kotlin.math.abs')
replace(activity, '        super.onCreate(savedInstanceState)\n',
        '        super.onCreate(savedInstanceState)\n        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE\n')
replace(activity, 'private const val DEFAULT_VIDEO_BIT_RATE = 4_000_000',
        'private const val DEFAULT_VIDEO_BIT_RATE = 1_500_000')
replace(activity, '    private var screenOn    = mutableStateOf(true)',
'''    private var screenOn    = mutableStateOf(true)
    // True = swipe to TV D-pad navigation, false = native touchscreen gestures.
    private var tvScrollMode = mutableStateOf(true)
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStepX = 0f
    private var gestureStepY = 0f
    private var gestureIsSwipe = false

    private fun handleTvTouch(ev: MotionEvent, w: Int, h: Int) {
        val ctrl = controlSender ?: return
        if (!tvScrollMode.value || ev.pointerCount > 1) {
            ctrl.sendTouchEvent(ev, w, h)
            return
        }
        // Small swipe step for responsive menus; avoiding MOVE floods is critical.
        val step = 30f * resources.displayMetrics.density
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureStartX = ev.x
                gestureStartY = ev.y
                gestureStepX = ev.x
                gestureStepY = ev.y
                gestureIsSwipe = false
            }
            MotionEvent.ACTION_MOVE -> {
                val vertical = abs(ev.y - gestureStartY) >= abs(ev.x - gestureStartX)
                if (!gestureIsSwipe && (abs(ev.x - gestureStartX) > step || abs(ev.y - gestureStartY) > step)) {
                    gestureIsSwipe = true
                }
                if (!gestureIsSwipe) return
                val delta = if (vertical) ev.y - gestureStepY else ev.x - gestureStepX
                val count = (abs(delta) / step).toInt().coerceAtMost(5)
                if (count > 0) {
                    val key = when {
                        vertical && delta < 0 -> KeyEvent.KEYCODE_DPAD_DOWN
                        vertical -> KeyEvent.KEYCODE_DPAD_UP
                        delta < 0 -> KeyEvent.KEYCODE_DPAD_RIGHT
                        else -> KeyEvent.KEYCODE_DPAD_LEFT
                    }
                    repeat(count) { ctrl.sendKeyTap(key) }
                    if (vertical) gestureStepY += if (delta > 0) count * step else -count * step
                    else gestureStepX += if (delta > 0) count * step else -count * step
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!gestureIsSwipe) ctrl.sendTap(ev.x, ev.y, w, h)
            }
            MotionEvent.ACTION_CANCEL -> gestureIsSwipe = false
        }
    }

    private fun handleTvScroll(ev: MotionEvent, w: Int, h: Int) {
        val ctrl = controlSender ?: return
        if (!tvScrollMode.value) { ctrl.sendScrollEvent(ev, w, h); return }
        val delta = ev.getAxisValue(MotionEvent.AXIS_VSCROLL)
        if (delta != 0f) repeat(abs(delta).toInt().coerceAtLeast(1).coerceAtMost(5)) {
            ctrl.sendKeyTap(if (delta > 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN)
        }
    }''')
replace(activity, '                    screenOn    = screenOn.value,',
'''                    screenOn    = screenOn.value,
                    tvScrollMode = tvScrollMode.value,
                    onToggleMode = { tvScrollMode.value = !tvScrollMode.value },
                    onNav = { keyCode -> controlSender?.sendKeyTap(keyCode) },''')
replace(activity, '                    onTouchEvent        = { ev, w, h -> controlSender?.sendTouchEvent(ev, w, h) },',
        '                    onTouchEvent        = { ev, w, h -> handleTvTouch(ev, w, h) },')
replace(activity, '                    onScrollEvent       = { ev, w, h -> controlSender?.sendScrollEvent(ev, w, h) },',
        '                    onScrollEvent       = { ev, w, h -> handleTvScroll(ev, w, h) },')
replace(activity, '                    enableAudio = true,', '                    enableAudio = false,\n                    maxSize     = 1280,', 2)
replace(activity, '        decodeJob?.cancel()\n', '        controlSender?.shutdown()\n        decodeJob?.cancel()\n')
# Update StreamScreen function signature AND FloatingControls signature with exact snippets
replace(activity, '    screenOn: Boolean,\n    onToggleScreen: () -> Unit,\n',
'''    screenOn: Boolean,
    tvScrollMode: Boolean,
    onToggleMode: () -> Unit,
    onNav: (Int) -> Unit,
    onToggleScreen: () -> Unit,
''', 2)
replace(activity, '                screenOn       = screenOn,\n                onToggleScreen = onToggleScreen,',
'''                screenOn       = screenOn,
                tvScrollMode  = tvScrollMode,
                onToggleMode  = onToggleMode,
                onNav         = onNav,
                onToggleScreen = onToggleScreen,''')
replace(activity, '                MenuItem("Disconnect", onDisconnect)\n',
'''                MenuItem(if (tvScrollMode) "MODE: TV swipe / D-pad" else "MODE: direct touch", onToggleMode)
                Row {
                    MenuItem("↑", { onNav(KeyEvent.KEYCODE_DPAD_UP) })
                    MenuItem("↓", { onNav(KeyEvent.KEYCODE_DPAD_DOWN) })
                    MenuItem("←", { onNav(KeyEvent.KEYCODE_DPAD_LEFT) })
                    MenuItem("→", { onNav(KeyEvent.KEYCODE_DPAD_RIGHT) })
                }
                Row {
                    MenuItem("OK", { onNav(KeyEvent.KEYCODE_DPAD_CENTER) })
                    MenuItem("BACK", { onNav(KeyEvent.KEYCODE_BACK) })
                    MenuItem("HOME", { onNav(KeyEvent.KEYCODE_HOME) })
                }
                MenuItem("Disconnect", onDisconnect)
''')

# 2. Control queue. Send on background thread, throttle MOVE, protect UI thread.
replace(sender, 'import android.view.MotionEvent',
        'import android.view.MotionEvent\nimport java.util.concurrent.LinkedBlockingDeque')
replace(sender, '    @Volatile var deviceHeight: Int = 0',
'''    @Volatile var deviceHeight: Int = 0

    private val outgoing = LinkedBlockingDeque<ByteArray>(48)
    @Volatile private var running = true
    @Volatile private var lastMoveNs = 0L
    private val writer = Thread({
        while (running) {
            try {
                stream.write(outgoing.takeFirst())
            } catch (_: InterruptedException) {
                break
            } catch (e: IOException) {
                Log.w(TAG, "Remote control writer stopped: ${e.message}")
                break
            }
        }
    }, "tv-touch-writer").apply { isDaemon = true; start() }

    fun shutdown() {
        running = false
        writer.interrupt()
        outgoing.clear()
    }

    // Short press: TV interfaces understand this even without touchscreen support.
    fun sendKeyTap(keyCode: Int) {
        sendKeyEvent(0, keyCode)
        sendKeyEvent(1, keyCode)
    }

    fun sendTap(sx: Float, sy: Float, sw: Int, sh: Int) {
        if (deviceWidth <= 0 || deviceHeight <= 0 || sw <= 0 || sh <= 0) return
        val x = (sx / sw * deviceWidth).toInt().coerceIn(0, deviceWidth - 1)
        val y = (sy / sh * deviceHeight).toInt().coerceIn(0, deviceHeight - 1)
        // Use a real finger pointer ID (not the special 'mouse' pointer -1).
        send(ScrcpyProtocol.buildTouchEvent(0, 0L, x, y, deviceWidth, deviceHeight, 1f))
        send(ScrcpyProtocol.buildTouchEvent(1, 0L, x, y, deviceWidth, deviceHeight, 0f))
    }''')
replace(sender, '''        if (deviceWidth == 0 || deviceHeight == 0) return

        val action''',
'''        if (deviceWidth <= 0 || deviceHeight <= 0 || surfaceWidth <= 0 || surfaceHeight <= 0) return
        if (event.actionMasked == MotionEvent.ACTION_MOVE) {
            val now = System.nanoTime()
            if (now - lastMoveNs < 16_000_000L) return
            lastMoveNs = now
        }

        val action''')
replace(sender, '        val x = (event.getX(pointerIdx) / surfaceWidth  * deviceWidth).toInt()',
        '        val x = (event.getX(pointerIdx) / surfaceWidth  * deviceWidth).toInt().coerceIn(0, deviceWidth - 1)')
replace(sender, '        val y = (event.getY(pointerIdx) / surfaceHeight * deviceHeight).toInt()',
        '        val y = (event.getY(pointerIdx) / surfaceHeight * deviceHeight).toInt().coerceIn(0, deviceHeight - 1)')
replace(sender, '''    private fun send(data: ByteArray) {
        try {
            stream.write(data)
        } catch (e: IOException) {
            Log.w(TAG, "Control send failed: ${e.message}")
        }
    }''',
'''    private fun send(data: ByteArray) {
        if (!running) return
        val isMove = data.size > 1 &&
            data[0].toInt() == ScrcpyProtocol.TYPE_INJECT_TOUCH_EVENT &&
            data[1].toInt() == MotionEvent.ACTION_MOVE
        if (outgoing.offerLast(data)) return
        if (isMove) return // Never allow drag frames to back up click/key input.
        // On saturation, replace a queued move, preserving down/up key ordering.
        val move = outgoing.firstOrNull { msg -> msg.size > 1 &&
            msg[0].toInt() == ScrcpyProtocol.TYPE_INJECT_TOUCH_EVENT &&
            msg[1].toInt() == MotionEvent.ACTION_MOVE }
        if (move != null) outgoing.remove(move)
        if (!outgoing.offerLast(data)) {
            Log.w(TAG, "Control queue full: dropped a command")
        }
    }''')
replace(sender, '''    private fun normalizePointerId(androidId: Int): Long =
        if (androidId == 0) ScrcpyProtocol.POINTER_MOUSE else androidId.toLong()''',
'''    private fun normalizePointerId(androidId: Int): Long = androidId.toLong()''')

# 3. Branding and version: keep package compatible with upstream while user tests v1.
replace(gradle, 'versionName = "1.0"', 'versionName = "1.0-TVTouch"')
print('PATCH OK: TV gestures, queued control, 720p streaming, no audio, floating D-pad')
